<?php

namespace WPMedia\Cloudflare;

use RuntimeException;

class AuthenticationException extends RuntimeException {}
