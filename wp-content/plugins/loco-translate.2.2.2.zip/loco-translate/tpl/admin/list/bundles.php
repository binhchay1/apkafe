<?php
/**
 * Generic listing of bundles of a given type
 */
$this->extend('../layout');

echo $this->render('../common/inc-table-filter');
echo $this->render('inc-table');