<?php 
//silents gold